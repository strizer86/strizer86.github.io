-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = false
-------------------------------------------------------

print("")
print("Active Auto-Tracker Configuration")
print("---------------------------------------------------------------------")
print("Enable Item Tracking:        ", AUTOTRACKER_ENABLE_ITEM_TRACKING)
print("Enable Location Tracking:    ", AUTOTRACKER_ENABLE_LOCATION_TRACKING)
if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
    print("Enable Debug Logging:        ", "true")
end
print("---------------------------------------------------------------------")
print("")

function autotracker_started()
    -- Invoked when the auto-tracker is activated/connected
end

AUTOTRACKER_IS_IN_TRIFORCE_ROOM = false
AUTOTRACKER_HAS_DONE_POST_GAME_SUMMARY = false

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function testFlag(segment, address, flag)
    local value = ReadU8(segment, address)
    local flagTest = value & flag

    if flagTest ~= 0 then
        return true
    else
        return false
    end    
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(item.Name, code, flag)
        end

        local flagTest = value & flag

        if flagTest ~= 0 then
            item.Active = true
        else
            item.Active = false
        end
	else
        print("Couldn't find item: ", code)
    end
end

function updateToggleItemFromByteAndFlagNegative(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(item.Name, code, flag)
        end

        local flagTest = value & flag

        if flagTest == 0 then
            item.Active = true
        else
            item.Active = false
        end
	else
        print("Couldn't find item: ", code)
    end
end

function updateKeyItemsFromMemorySegment(segment)
    if testFlag(segment, 0x7E0A9D, 0x08) then

	updateToggleItemFromByteAndFlag(segment, "antibarrier", 0x7E0A4A, 0x01)
	updateToggleItemFromByteAndFlag(segment, "subkey", 0x7E0A4A, 0x02)
	updateToggleItemFromByteAndFlag(segment, "hiryuu", 0x7E0A4A, 0x04)
	updateToggleItemFromByteAndFlag(segment, "bridgekey", 0x7E0A4A, 0x08)
	updateToggleItemFromByteAndFlag(segment, "bait", 0x7E0A4A, 0x10)
	updateToggleItemFromByteAndFlag(segment, "fire", 0x7E0A4A, 0x20)
	updateToggleItemFromByteAndFlag(segment, "steamshipkey", 0x7E0A4A, 0x40)
	updateToggleItemFromByteAndFlag(segment, "walsekey", 0x7E0A4A, 0x80)
	
	updateToggleItemFromByteAndFlag(segment, "fallspage", 0x7E0A4B, 0x02)
	updateToggleItemFromByteAndFlag(segment, "trenchpage", 0x7E0A4B, 0x04)
	updateToggleItemFromByteAndFlag(segment, "shrinepage", 0x7E0A4B, 0x08)
	updateToggleItemFromByteAndFlag(segment, "pyramidpage", 0x7E0A4B, 0x10)
	updateToggleItemFromByteAndFlag(segment, "bracelet", 0x7E0A4B, 0x80)
	
	updateToggleItemFromByteAndFlag(segment, "moogle", 0x7E0A4C, 0x02)
	updateToggleItemFromByteAndFlag(segment, "adamantite", 0x7E0A4C, 0x04)
	updateToggleItemFromByteAndFlag(segment, "radar", 0x7E0A4C, 0x20)
	
	updateToggleItemFromByteAndFlag(segment, "tablet4", 0x7E0A4D, 0x04)
	updateToggleItemFromByteAndFlag(segment, "tablet3", 0x7E0A4D, 0x08)
	updateToggleItemFromByteAndFlag(segment, "tablet2", 0x7E0A4D, 0x10)
	updateToggleItemFromByteAndFlag(segment, "tablet1", 0x7E0A4D, 0x20)
	updateToggleItemFromByteAndFlag(segment, "branch", 0x7E0A4D, 0x80)

	updateToggleItemFromByteAndFlag(segment, "siren", 0x7E0A18, 0x02)
	updateToggleItemFromByteAndFlag(segment, "magisa", 0x7E0A18, 0x08)
	updateToggleItemFromByteAndFlag(segment, "shiva", 0x7E0A18, 0x20)
	updateToggleItemFromByteAndFlag(segment, "galura", 0x7E0A18, 0x80)
        updateToggleItemFromByteAndFlag(segment, "liquidflame", 0x7E0A19, 0x80)
	updateToggleItemFromByteAndFlag(segment, "ironclaw", 0x7E0A1A, 0x02)
	updateToggleItemFromByteAndFlag(segment, "sandworm", 0x7E0A1B, 0x10)
	updateToggleItemFromByteAndFlag(segment, "crayclaw", 0x7E0A1C, 0x10)
	updateToggleItemFromByteAndFlag(segment, "gilga2", 0x7E0A1C, 0x20)
	updateToggleItemFromByteAndFlag(segment, "adamant", 0x7E0A1D, 0x01)
	updateToggleItemFromByteAndFlag(segment, "solcannon", 0x7E0A1D, 0x08)
	updateToggleItemFromByteAndFlag(segment, "titan", 0x7E0A1E, 0x01)
	updateToggleItemFromByteAndFlag(segment, "puroboros", 0x7E0A1E, 0x08)
	updateToggleItemFromByteAndFlag(segment, "chimbrain", 0x7E0A1E, 0x10)
	updateToggleItemFromByteAndFlag(segment, "abductor", 0x7E0A20, 0x02)
	updateToggleItemFromByteAndFlag(segment, "hiryuuplant", 0x7E0A20, 0x40)
	updateToggleItemFromByteAndFlag(segment, "guardian", 0x7E0A22, 0x20)
	updateToggleItemFromByteAndFlag(segment, "atomos", 0x7E0A22, 0x80)
	updateToggleItemFromByteAndFlag(segment, "antlion", 0x7E0A23, 0x80)
	updateToggleItemFromByteAndFlag(segment, "ramuh", 0x7E0A24, 0x04)
	updateToggleItemFromByteAndFlag(segment, "leviathan", 0x7E0A26, 0x04)
	updateToggleItemFromByteAndFlag(segment, "bahamut", 0x7E0A2E, 0x10)
	updateToggleItemFromByteAndFlag(segment, "wingraptor", 0x7E0A38, 0x01)
	updateToggleItemFromByteAndFlag(segment, "karlabos", 0x7E0A38, 0x04)
	updateToggleItemFromByteAndFlag(segment, "byblos", 0x7E0A39, 0x04)
	updateToggleItemFromByteAndFlag(segment, "tyrasaurus", 0x7E0A3B, 0x10)
	updateToggleItemFromByteAndFlag(segment, "gilga4", 0x7E0A3D, 0x08)
	updateToggleItemFromByteAndFlag(segment, "minotaurus", 0x7E0A42, 0x01)
	updateToggleItemFromByteAndFlag(segment, "catastroph", 0x7E0A42, 0x04)
	updateToggleItemFromByteAndFlag(segment, "apocalypse", 0x7E0A42, 0x08)
	updateToggleItemFromByteAndFlag(segment, "apanda", 0x7E0A42, 0x10)
	updateToggleItemFromByteAndFlag(segment, "halicarnaso", 0x7E0A42, 0x20)
	updateToggleItemFromByteAndFlag(segment, "gargoyle", 0x7E0A42, 0x40)
	updateToggleItemFromByteAndFlag(segment, "twintania", 0x7E0A42, 0x80)
	updateToggleItemFromByteAndFlag(segment, "necrophobe", 0x7E0A43, 0x01)
	updateToggleItemFromByteAndFlag(segment, "calofisteri", 0x7E0A43, 0x02)
	updateToggleItemFromByteAndFlag(segment, "omniscient", 0x7E0A52, 0x04)

	updateToggleItemFromByteAndFlagNegative(segment, "merugene", 0x7E0A55, 0x01)
	updateToggleItemFromByteAndFlagNegative(segment, "triton", 0x7E0A58, 0x01)
	updateToggleItemFromByteAndFlagNegative(segment, "shoat", 0x7E0A58, 0x02)
	updateToggleItemFromByteAndFlagNegative(segment, "odin", 0x7E0A59, 0x80)
	updateToggleItemFromByteAndFlagNegative(segment, "exdeath", 0x7E0A63, 0x80)
	updateToggleItemFromByteAndFlagNegative(segment, "archaeavis", 0x7E0A6D, 0x20)
	updateToggleItemFromByteAndFlagNegative(segment, "gogo", 0x7E0A71, 0x08)
	updateToggleItemFromByteAndFlagNegative(segment, "carbunkle", 0x7E0A84, 0x80)
	updateToggleItemFromByteAndFlagNegative(segment, "ifrit", 0x7E0A86, 0x80)
	updateToggleItemFromByteAndFlagNegative(segment, "stalker", 0x7E0A9C, 0x08)
	updateToggleItemFromByteAndFlagNegative(segment, "golem", 0x7E0AA3, 0x40)
        updateToggleItemFromByteAndFlagNegative(segment, "gilga1", 0x7E0AB7, 0x01)

	local item = Tracker:FindObjectForCode("gilga3")	
	if testFlag(segment, 0x7E0A21, 0x10) and testFlag(segment, 0x7E0AB4, 0x02) then
		item.Active = true
	else
		item.Active = false
	end

    end	
    return true
end

function updateSpellsFromMemorySegment(segment)

	updateToggleItemFromByteAndFlag(segment, "death", 0x7E0956, 0x08)
	
	local item = Tracker:FindObjectForCode("break")	
	if testFlag(segment, 0x7E0951, 0x20) or testFlag(segment, 0x7E0955, 0x02) or testFlag(segment, 0x7E095A, 0x80) then
		item.Active = true
	else
		item.Active = false
	end
	
	item = Tracker:FindObjectForCode("sleep")
	if testFlag(segment, 0x7E0950, 0x04) or testFlag(segment, 0x7E0955, 0x80) then	    
		item.Active = true
	else
		item.Active = false
	end
	
	item = Tracker:FindObjectForCode("mute")
	if testFlag(segment, 0x7E0950, 0x08) or testFlag(segment, 0x7E0952, 0x04) then	    
		item.Active = true
	else
		item.Active = false
	end
	
	item = Tracker:FindObjectForCode("slow")
	if testFlag(segment, 0x7E0956, 0x01) or testFlag(segment, 0x7E0958, 0x80) then	    
		item.Active = true
	else
		item.Active = false
	end

    return true
end

function updateFormationFromMemorySegment(segment)

	InvalidateReadCaches() --used here because of reasons
	
	local value = ReadU16(segment, 0x7E04F0)
	
	if value > 0x01FF then
		return true --garbage value don't even do more
	end
	
	local formationArray = 	{
		[0x004C] = "ramuhx",
		[0x00A5] = "shoatx",
		[0x00BB] = "golemx",
		[0x01B7] = "wingraptorx",
		[0x01B8] = "karlabosx",
		[0x01B9] = "sirenx",
		[0x01BA] = "magisax",
		[0x01BB] = "galurax",
		[0x01BC] = "liquidflamex",
		[0x01BD] = "ironclawx",
		[0x01BE] = "byblosx",
		[0x01BF] = "sandwormx",
		[0x01C0] = "adamantx",
		[0x01C3] = "solcannonx",
		[0x01C4] = "archaeavisx",
		[0x01C5] = "chimbrainx",
		[0x01C6] = "titanx",
		[0x01C7] = "puroborosx",
		[0x01C9] = "gilga1x",
		[0x01D0] = "gilga2x",
		[0x01D1] = "tyrasaurusx",
		[0x01D2] = "abductorx",
		[0x01D3] = "hiryuuplantx",
		[0x01D4] = "gilga3x",
		[0x01D5] = "atomosx",
		[0x01D6] = "guardianx",
		[0x01D7] = "carbunklex",
		[0x01D8] = "gilga4x",
		[0x01DA] = "antlionx",
		[0x01DE] = "halicarnasox",
		[0x01E0] = "merugenex",
		[0x01E1] = "odinx",
		[0x01E2] = "gargoylex",
		[0x01E3] = "tritonx",
		[0x01E4] = "omniscientx",
		[0x01E5] = "minotaurusx",
		[0x01E6] = "leviathanx",
		[0x01E7] = "stalkerx",
		[0x01E8] = "gogox",
		[0x01E9] = "bahamutx",
		[0x01EE] = "ifritx",
		[0x01F1] = "shivax",
		[0x01F2] = "calofisterix",
		[0x01F3] = "apocalypsex",
		[0x01F4] = "catastrophx",
		[0x01F5] = "necrophobex",
		[0x01F6] = "twintaniax",
		[0x01F8] = "apandax",
		[0x01FA] = "crayclawx"
	}
	
	local code = formationArray[value]	
	if code then --checks if we have a code for the given formation	
		local item = Tracker:FindObjectForCode(code)
		if item then
			item.Active = true
		else
			print("Couldn't find item: ", code)
		end
	end
	
	return true
end


-- FF5
ScriptHost:AddMemoryWatch("FF5 Key Items and Checks", 0x7E0A14, 0xBB, updateKeyItemsFromMemorySegment)
ScriptHost:AddMemoryWatch("FF5 Spells", 0x7E0950, 0xA0, updateSpellsFromMemorySegment)
ScriptHost:AddMemoryWatch("FF5 Formation ID", 0x7E04F0, 0x2, updateFormationFromMemorySegment)













