--  Load configuration options up front
ScriptHost:LoadScript("scripts/settings.lua")

Tracker:AddItems("items/items.json")
Tracker:AddMaps("maps/maps.json")
Tracker:AddLocations("locations/locations.json")
Tracker:AddLayouts("layouts/tracker.json")

if not (string.find(Tracker.ActiveVariantUID, "mintracker")) then
	Tracker:AddLayouts("layouts/standard_broadcast.json")
else
	Tracker:AddLayouts("layouts/keyitem_broadcast.json")
end

if _VERSION == "Lua 5.3" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
else
    print("Auto-tracker is unsupported by your tracker version")
end