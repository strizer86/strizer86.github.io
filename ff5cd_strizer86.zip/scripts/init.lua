Tracker:AddItems("items/items.json")
Tracker:AddMaps("maps/maps.json")
Tracker:AddLocations("locations/locations.json")
Tracker:AddLayouts("layouts/tracker.json")

if not (string.find(Tracker.ActiveVariantUID, "keyitems")) then
	Tracker:AddLayouts("layouts/standard_broadcast.json")
else
	Tracker:AddLayouts("layouts/keyitem_broadcast.json")
end
